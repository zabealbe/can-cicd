Each generic hashtable type requires an often small independent
compilation unit so we keep these here.
