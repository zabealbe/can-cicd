Essential files extracted from the luthor scanner - a generic scanner
similar to a handwritten scanner, but covering many common cases by
default.
